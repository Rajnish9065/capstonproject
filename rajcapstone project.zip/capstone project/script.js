// Preloader
setTimeout(() => {
    document.querySelector('.preloader').classList.add('hidden');
}, 2000);

// Date and time
function updateDateTime() {
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    const timeStr = now.toLocaleTimeString('en-US');

    document.getElementById('CurDate').textContent = dateStr;
    document.getElementById('CurTime').textContent = timeStr;
}
updateDateTime();
setInterval(updateDateTime, 1000);

// Elements
const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('sendMessage');
const talkButton = document.getElementById('talk');
const contentDisplay = document.getElementById('content');
const audio = document.getElementById('audio');

// Greetings
const greetings = ['Hello boss', 'Hello sir', 'Hi master'];

// Music
const music = [
    "https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3",
    "https://assets.mixkit.co/music/preview/mixkit-game-show-suspense-waiting-667.mp3",
    "https://assets.mixkit.co/music/preview/mixkit-deep-urban-623.mp3"
];

// Speech recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();
recognition.continuous = false;
recognition.lang = 'en-US';

// On load
window.addEventListener("load", () => {
    speak('Activating Inertia');
    speak('Going online');
    wishMe();
});

// Add message
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');

    const timeDiv = document.createElement('div');
    timeDiv.classList.add('message-time');
    timeDiv.textContent = getCurrentTime();

    messageDiv.innerHTML = text;
    messageDiv.appendChild(timeDiv);
    chatMessages.appendChild(messageDiv);

    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Time format
function getCurrentTime() {
    const now = new Date();
    return now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
}

// Send Message
function sendMessage() {
    const message = userInput.value.trim();
    if (message !== '') {
        addMessage(message, 'user');
        userInput.value = '';
        if (audio) audio.play();
        processCommand(message);
    }
}

// Core Function
function processCommand(message) {
    const lowerMsg = message.toLowerCase();
    setTimeout(() => {
        let finalText = '';

        if (lowerMsg.includes('hi') || lowerMsg.includes('hello') || lowerMsg.includes('hii') || lowerMsg.includes('hey')) {
            finalText = greetings[Math.floor(Math.random() * greetings.length)];
        }
        else if (lowerMsg.includes('how are you') || lowerMsg.includes('whats up')) {
            finalText = 'I am fine boss, tell me how can I help you';
        }
        else if (lowerMsg.includes('reality')) {
            finalText = 'Wake up to reality. Nothing ever goes as planned in this world...';
        }
        else if (lowerMsg.includes('name')) {
            finalText = 'My name is Inertia';
        }
        else if (lowerMsg.includes('play music')) {
            finalText = 'Playing music';
            if (audio) {
                audio.src = music[Math.floor(Math.random() * music.length)];
                audio.play();
            }
        }
        else if (lowerMsg.includes('pause music')) {
            if (audio) audio.pause();
            finalText = 'Music paused';
        }
        else if (lowerMsg.includes('open google')) {
            window.open(`http://google.com`, "_blank");
            finalText = 'Opening Google';
        }
        else if (lowerMsg.includes('open instagram')) {
            window.open(`http://instagram.com`, "_blank");
            finalText = 'Opening Instagram';
        }
        else if (lowerMsg.includes('open youtube')) {
            window.open(`http://youtube.com`, "_blank");
            finalText = 'Opening YouTube';
        }
        else if (lowerMsg.includes('screenshot')) {
            takeScreenshot();
            finalText = 'Taking screenshot';
        }
        else if (lowerMsg.includes('notes') || lowerMsg.includes('note')) {
            document.getElementById('notepadPopup').classList.remove('hidden');
            notepadArea.value = localStorage.getItem('userNote') || '';
            finalText = 'Opening notepad';
        }
        else if (lowerMsg.includes('todo') || lowerMsg.includes('task list')) {
            document.getElementById('todoPopup').classList.remove('hidden');
            finalText = 'Here\'s your to-do list';
        }
        else if (lowerMsg.includes('open calculator') || lowerMsg.includes('calculate')) {
            document.getElementById('calculatorPopup').classList.remove('hidden');
            finalText = 'Opening calculator';
        }
        else if (lowerMsg.includes('exit') || lowerMsg.includes('bye') || lowerMsg.includes('sleep')) {
            finalText = 'Goodbye boss! Inertia signing off.';
            speak(finalText);
            setTimeout(() => {
                document.body.classList.add('shutdown');
                setTimeout(() => {
                    document.querySelector('.shutdown-screen').classList.remove('hidden');
                }, 1000);
            }, 2000);
        }

        // 🌦️ Weather API
        else if (lowerMsg.includes('weather') || lowerMsg.includes('mausam')) {
            finalText = 'Getting the current weather...';
            addMessage(finalText, 'bot');
            speak(finalText);
            fetch(`https://api.openweathermap.org/data/2.5/weather?q=Patna&units=metric&appid=21d6b1eac04f379b5f1eb69bc1c61b67`)
                .then(res => res.json())
                .then(data => {
                    const temp = data.main.temp;
                    const condition = data.weather[0].description;
                    const weatherMsg = `The temperature in ${data.name} is ${temp}°C with ${condition}.`;
                    addMessage(weatherMsg, 'bot');
                    speak(weatherMsg);
                })
                .catch(err => {
                    console.error(err);
                    const errMsg = "Sorry, I couldn't fetch the weather right now.";
                    addMessage(errMsg, 'bot');
                    speak(errMsg);
                });
        }

        // 📰 News API
        else if (lowerMsg.includes('news') || lowerMsg.includes('headlines')) {
            finalText = 'Fetching the latest news...';
            addMessage(finalText, 'bot');
            speak(finalText);
            fetch(`https://newsapi.org/v2/top-headlines?country=in&pageSize=3&apiKey=600fa99d6a35465fa066228fcb9d0860`)
                .then(res => res.json())
                .then(data => {
                    if (data.articles && data.articles.length > 0) {
                        const newsList = data.articles.map((article, i) => `${i + 1}. ${article.title}`).join('\n');
                        const newsMsg = `Here are the top headlines:\n${newsList}`;
                        addMessage(newsMsg, 'bot');
                        speak(newsMsg);
                    } else {
                        const noNews = "No news found right now.";
                        addMessage(noNews, 'bot');
                        speak(noNews);
                    }
                })
                .catch(err => {
                    console.error(err);
                    const errMsg = "Sorry, I couldn't fetch the news right now.";
                    addMessage(errMsg, 'bot');
                    speak(errMsg);
                });
        }

        // Gemini AI fallback
        else {
            fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=600fa99d6a35465fa066228fcb9d0860', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contents: [{ parts: [{ text: message }] }] })
            })
                .then(response => response.json())
                .then(data => {
                    const geminiResponse = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Sorry, I couldn't get an answer.";
                    addMessage(geminiResponse, 'bot');
                    speak(geminiResponse);
                })
                .catch(error => {
                    console.error('Gemini API error:', error);
                    const errorMsg = "I didn't understand that. Try again.";
                    addMessage(errorMsg, 'bot');
                    speak(errorMsg);
                });
            return;
        }

        if (finalText !== '') {
            addMessage(finalText, 'bot');
            if (!lowerMsg.includes('exit') && !lowerMsg.includes('bye') && !lowerMsg.includes('sleep')) {
                speak(finalText);
            }
        }
    }, 300);
}

// Speak
function speak(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1;
        utterance.pitch = 1;
        utterance.volume = 1;
        speechSynthesis.speak(utterance);
    }
}

// Wish greeting
function wishMe() {
    const hour = new Date().getHours();
    let greeting = hour >= 5 && hour < 12 ? 'Good morning' : (hour >= 12 && hour < 18 ? 'Good afternoon' : 'Good evening');
    greeting += ', boss. How can I assist you today?';
    addMessage(greeting, 'bot');
    speak(greeting);
}

// Events
sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });
talkButton.addEventListener('click', () => {
    recognition.start();
    addMessage('Listening...', 'bot');
});
recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    sendMessage();
};
recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    addMessage('Error: ' + event.error, 'bot');
};
recognition.onend = () => {
    const messages = chatMessages.querySelectorAll('.message');
    if (messages.length > 0 && messages[messages.length - 1].textContent.includes('Listening...')) {
        chatMessages.removeChild(messages[messages.length - 1]);
    }
};
